// ─────────────────────────────────────────────────────────────
// reference-tab.js
// The Brand Reference browsing grid.
// (source: original index.html lines 3979-4125)
// ─────────────────────────────────────────────────────────────

// ══════════════════════════════════════════════════════════════
// BRAND REFERENCE
// ══════════════════════════════════════════════════════════════
let refBrand='all',refGroup=null,refLF='all';

document.querySelectorAll('.rsb-btn').forEach(btn=>{
  btn.addEventListener('click',function(){
    document.querySelectorAll('.rsb-btn').forEach(b=>b.classList.remove('active'));
    this.classList.add('active');
    const brand=this.dataset.brand,group=this.dataset.group;
    if(brand){refBrand=brand;refGroup=null;}
    if(group){refGroup=group;refBrand='all';}
    syncRefMobileSwitcher();
    renderRef();
    if(isMobile()) setTimeout(closeSidebars,80);
  });
});

// Mobile brand/group dropdown — mirrors the sidebar's filter state so users
// don't need to open the (desktop-only) sidebar or rotate to landscape to
// pick a brand. Keeps a single source of truth (refBrand/refGroup) shared
// with the sidebar buttons rather than duplicating filter logic.
function setRefFromDropdown(value){
  const [kind,val]=value.split(':');
  if(kind==='brand'){ refBrand=val; refGroup=null; }
  else if(kind==='group'){ refGroup=val; refBrand='all'; }
  // Keep the desktop sidebar's active state in sync too, in case the window
  // is resized from mobile to desktop width without a page reload.
  document.querySelectorAll('.rsb-btn').forEach(b=>{
    const match=(kind==='brand'&&b.dataset.brand===val)||(kind==='group'&&b.dataset.group===val);
    b.classList.toggle('active', match);
  });
  renderRef();
}
// Reflects the current refBrand/refGroup state back into the <select> —
// called whenever the sidebar buttons change state so both controls agree.
function syncRefMobileSwitcher(){
  const sel=document.getElementById('ref-mobile-switcher');
  if(!sel) return;
  sel.value = refGroup ? ('group:'+refGroup) : ('brand:'+refBrand);
}

function setRefLF(btn,lf){
  refLF=lf;
  document.querySelectorAll('.ref-filters .filt-btn').forEach(b=>b.classList.toggle('active', b===btn));
  renderRef();
}

function getRefFiltered(){
  const q=(document.getElementById('ref-search')||{value:''}).value.trim().toLowerCase();
  return COLORS.filter(c=>{
    if(refBrand!=='all'&&c.brand!==refBrand) return false;
    if(refGroup&&c.group!==refGroup) return false;
    if(refLF==='I'&&c.lf!=='I') return false;
    if(refLF==='T'&&c.transparency!=='T') return false;
    if(refLF==='gran'&&!c.gran) return false;
    if(refLF==='single'&&!c.single) return false;
    if(refLF==='O'&&c.transparency!=='O') return false;
    if(q&&!c.name.toLowerCase().includes(q)&&!c.pigment.toLowerCase().includes(q)) return false;
    return true;
  });
}

function paletteOptionsHtml(){
  if(!palettes.length) return '<option value="">No palettes — create one first</option>';
  return palettes.map(p=>`<option value="${p.id}">${p.name}</option>`).join('');
}

function renderRef(){
  clearQ();
  const wrap=document.getElementById('ref-grid-wrap');
  if(!wrap) return;
  const filtered=getRefFiltered();
  if(!filtered.length){wrap.innerHTML='<div class="no-ref-results">No colors match your filters.</div>';return;}
  // Performance: warn if rendering many cards
  if(filtered.length>300){
    wrap.innerHTML='<div class="no-ref-results" style="color:var(--rust);">'+filtered.length+' colors — use the brand or group filter to narrow results for best performance.</div>';
    return;
  }

  const byGroup={};
  GROUP_ORDER.forEach(g=>byGroup[g]=[]);
  filtered.forEach(c=>{
    // Attach cid once per color to avoid recomputing it separately for the colorMap
    c._cid=`ref_${c.brand}_${c.name}`.replace(/[^a-zA-Z0-9_]/g,'_');
    if(byGroup[c.group])byGroup[c.group].push(c);
  });

  let html='';
  GROUP_ORDER.forEach(g=>{
    const cols=byGroup[g];if(!cols.length) return;
    html+=`<div class="ref-group-header"><h3>${GROUP_LABELS[g]||g}</h3><span class="ref-group-count">${cols.length}</span></div><div class="ref-grid">`;
    cols.forEach(c=>{
      const cid=c._cid;
      const sn=c.name.replace(/'/g,"\\'"),sb=c.brand.replace(/'/g,"\\'");
      const bTag=refBrand==='all'?`<div class="ref-brand-tag">${BRAND_LABELS[c.brand]||c.brand}</div>`:'';
      html+=`<div class="ref-card" onclick="openRefChip('${sn}','${sb}')">
        <div class="ref-swatch" style="background:${c.hex};" data-cid="rs_${cid}">
          <canvas id="rs_${cid}"></canvas>
        </div>
        <div class="ref-ts" data-cid="rt_${cid}">
          <canvas id="rt_${cid}"></canvas>
          <span class="ref-ts-label">${c.transparency==='T'?'transparent →':c.transparency==='ST'?'semi →':'opaque'}</span>
        </div>
        <div class="ref-body">
          <div class="ref-name">${c.name}</div>
          <div class="ref-pig">${c.pigment}</div>
          <div class="ref-meta"><span class="lbadge lf-${c.lf}">${c.lf}</span>
          <span class="ref-transp">${c.gran?'Gran·':''} ${c.transparency}</span></div>
          ${bTag}
        </div>
      </div>`;
    });
    html+='</div>';
  });
  wrap.innerHTML=html;

  // IntersectionObserver for canvas renders — reuse already-computed _cid
  if(window._refIO) window._refIO.disconnect();
  const colorMap={};
  filtered.forEach(c=>{colorMap['rs_'+c._cid]=c;colorMap['rt_'+c._cid]=c;});
  const io=new IntersectionObserver(entries=>{
    entries.forEach(e=>{
      if(!e.isIntersecting) return;
      const area=e.target,cid=area.dataset.cid;
      if(!cid) return;
      const c=colorMap[cid];if(!c) return;
      const cv=document.getElementById(cid);if(!cv) return;
      const W=area.offsetWidth||130,H=area.offsetHeight||72;
      if(cid.startsWith('rs_')) queueRender(()=>renderSwatchCanvas(cv,c.hex,c.gran,c.transparency,W,H));
      else queueRender(()=>renderTranspCanvas(cv,c.hex,c.transparency,W,H));
      io.unobserve(area);
    });
  },{rootMargin:'300px'});
  wrap.querySelectorAll('[data-cid]').forEach(el=>io.observe(el));
  window._refIO=io;

  // Update brand sidebar counts using a single pass over COLORS
  const brandCounts={all:COLORS.length};
  COLORS.forEach(c=>{brandCounts[c.brand]=(brandCounts[c.brand]||0)+1;});
  const ids=['all','daniel-smith','winsor-newton','schmincke','holbein','sennelier','mgraham','qor','blockx','mijello','utrecht','schpirerr-farben'];
  ids.forEach(b=>{
    const el=document.getElementById('rcnt-'+b);if(!el) return;
    el.textContent='('+(brandCounts[b]||0)+')';
  });
}

